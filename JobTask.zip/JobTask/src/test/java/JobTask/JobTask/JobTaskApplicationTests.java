package JobTask.JobTask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
