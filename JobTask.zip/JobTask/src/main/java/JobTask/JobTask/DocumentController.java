package JobTask.JobTask;

import com.opencsv.CSVReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Controller
public class DocumentController {

    @Autowired
    private DocumentService fileService;

   // String totalScenarios ;
   // String passScenarios ;

    //Wyświetlanie pliku html "file", w tym wszystkich dokumentów.

    @GetMapping("/")
    public String get(Model model) {
        List<Document> files = fileService.getAllFiles();
        model.addAttribute("files", files);
        return "file";
    }

    //Wgrywanie pliku do bazy
    @PostMapping("/upload")     //MultipartFile -wiele plików
    public String uploadManyFiles(@RequestParam("files") MultipartFile[] files) {
        for (MultipartFile file : files) {
            fileService.saveFile(file);
        }
        return "redirect:/file";

    }

    //Pobieranie pliku z bazy danych
    @GetMapping("/download/{fileId}")
    public ResponseEntity<ByteArrayResource> downloadFile(@PathVariable Long fileId) {
        Document doc = fileService.getFile(fileId).get();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(doc.getType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment:filename=\"" + doc.getName() + "\"")
                .body(new ByteArrayResource(doc.getData()));
    }

    //Proste usuwanie pliku z bazy danych
    @GetMapping("/delete/{fileId}")
    public String deleteFile(@PathVariable long fileId) {
        //fileService.
        fileService.deleteFile(fileId);
        return "redirect:/file";
    }

    @GetMapping("/read/{fileId}")
    public String readFile(@PathVariable long fileId, Model model) throws FileNotFoundException {
        Document doc = fileService.getFile(fileId).get();
        model.addAttribute("doc", doc);

     /*   FileInputStream fis = new FileInputStream(String.valueOf(doc));
        int r = 0;
        for (r = 0; r < 20; r++) {
            System.out.print((char) r);      //prints the content of the file
        }
*/
        return "read";


    }


    @GetMapping ("/fileread")
    String home(ModelMap modelMap) throws Exception{
        List<String> totalScenarios = new ArrayList<>();
        List<String> totalScenarios2 = new ArrayList<>();
        List<String> passScenarios = new ArrayList<>();
        CSVReader reader = new CSVReader(new FileReader("Workbook2.csv"));
        List<String[]> myEnteries = reader.readAll();
        reader.close();
        for(String[] entry:myEnteries)
        {
            totalScenarios.add(Arrays.toString(entry));
            passScenarios.add(entry.toString());
        }

        modelMap.addAttribute("myEnteries", myEnteries);
        modelMap.addAttribute("totalScenarios", totalScenarios);
        modelMap.addAttribute("totalScenarios2", totalScenarios );
        modelMap.addAttribute("passScenarios", passScenarios);

        return "fileread";
    }



}





