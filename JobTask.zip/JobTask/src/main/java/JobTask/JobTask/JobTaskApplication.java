package JobTask.JobTask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobTaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobTaskApplication.class, args);
	}




}
